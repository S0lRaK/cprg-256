https://developer.mozilla.org/en-US/docs/Web/API/XMLHttpRequest

https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods

https://nodejs.org/en/

https://eslint.org/

https://www.freeformatter.com/json-to-xml-converter.html#ad-output
